Place the official ULB/Kaggle creditcard.csv here. Both phases reuse this one file.
Dataset: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
